var searchData=
[
  ['buffer_5fsize_128',['BUFFER_SIZE',['../const_8h.html#a6b20d41d6252e9871430c242cb1a56e7',1,'const.h']]]
];
