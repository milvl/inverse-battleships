var searchData=
[
  ['buffer_5fsize_3',['BUFFER_SIZE',['../const_8h.html#a6b20d41d6252e9871430c242cb1a56e7',1,'BUFFER_SIZE():&#160;const.h'],['../namespaceclient.html#ac96afc5e4b315ea02e762492e50fda52',1,'client.BUFFER_SIZE()']]]
];
