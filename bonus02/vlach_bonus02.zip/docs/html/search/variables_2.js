var searchData=
[
  ['correct_5finteraction_112',['CORRECT_INTERACTION',['../namespaceclient.html#ad8fe21caac369fdb31568a309b6657d2',1,'client']]]
];
