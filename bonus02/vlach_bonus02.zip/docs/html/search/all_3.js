var searchData=
[
  ['client_4',['client',['../namespaceclient.html',1,'']]],
  ['client_2epy_5',['client.py',['../client_8py.html',1,'']]],
  ['client_5fso_5fnull_6',['CLIENT_SO_NULL',['../err__messages_8h.html#aa0dba4492ad530aa6c531809bc9b826c',1,'CLIENT_SO_NULL():&#160;err_messages.h'],['../server_8c.html#aa0dba4492ad530aa6c531809bc9b826c',1,'CLIENT_SO_NULL():&#160;server.c']]],
  ['client_5fthread_7',['client_thread',['../namespaceclient.html#a2432ffca67564d8b6c373d12265bd087',1,'client']]],
  ['configure_5faddress_8',['configure_address',['../server_8c.html#a1fa1d807748a43c1fe69ccf4c3156ef6',1,'server.c']]],
  ['const_2eh_9',['const.h',['../const_8h.html',1,'']]],
  ['correct_5finteraction_10',['CORRECT_INTERACTION',['../namespaceclient.html#ad8fe21caac369fdb31568a309b6657d2',1,'client']]]
];
