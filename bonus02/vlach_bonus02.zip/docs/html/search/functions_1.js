var searchData=
[
  ['client_5fthread_84',['client_thread',['../namespaceclient.html#a2432ffca67564d8b6c373d12265bd087',1,'client']]],
  ['configure_5faddress_85',['configure_address',['../server_8c.html#a1fa1d807748a43c1fe69ccf4c3156ef6',1,'server.c']]]
];
