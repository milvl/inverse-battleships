var searchData=
[
  ['fd_5fsock_16',['fd_sock',['../structsession.html#ae587372a1d984a3b127974e26ff0230c',1,'session']]],
  ['fn_5ferr_17',['FN_ERR',['../server_8c.html#a053362afdac5161fdf05090ceae1f789',1,'server.c']]]
];
