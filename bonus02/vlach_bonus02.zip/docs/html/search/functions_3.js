var searchData=
[
  ['init_5fmaster_5fsocket_90',['init_master_socket',['../server_8c.html#ac12c81708f20039b3b8763a4a1cadd28',1,'server.c']]],
  ['init_5fsession_91',['init_session',['../session_8c.html#ac0c3f84daa86d3478921e697233856fe',1,'init_session(session *p_session, int fd_sock, int num, int *p_err):&#160;session.c'],['../session_8h.html#ac0c3f84daa86d3478921e697233856fe',1,'init_session(session *p_session, int fd_sock, int num, int *p_err):&#160;session.c']]]
];
