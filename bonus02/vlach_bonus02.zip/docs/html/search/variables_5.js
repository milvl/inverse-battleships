var searchData=
[
  ['fd_5fsock_116',['fd_sock',['../structsession.html#ae587372a1d984a3b127974e26ff0230c',1,'session']]]
];
