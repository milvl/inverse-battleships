var searchData=
[
  ['buffer_5fsize_111',['BUFFER_SIZE',['../namespaceclient.html#ac96afc5e4b315ea02e762492e50fda52',1,'client']]]
];
