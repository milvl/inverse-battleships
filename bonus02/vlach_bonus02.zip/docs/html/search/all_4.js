var searchData=
[
  ['disconnect_5fbefore_5fauth_11',['DISCONNECT_BEFORE_AUTH',['../namespaceclient.html#ac3e61a094bf9c37477496ac027fd9e85',1,'client']]],
  ['disconnect_5fbefore_5fval_12',['DISCONNECT_BEFORE_VAL',['../namespaceclient.html#ad31d172d20c889c33780517dd67bd494',1,'client']]]
];
