var searchData=
[
  ['_5f_5fserver_5fc_0',['__SERVER_C',['../server_8c.html#a9e25a694975b12e251b96389b1d29aea',1,'server.c']]]
];
