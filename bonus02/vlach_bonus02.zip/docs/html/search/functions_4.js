var searchData=
[
  ['main_92',['main',['../namespaceclient.html#a18d2f0bd3df369370bdb40b86fe2892b',1,'client.main()'],['../server_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;server.c']]]
];
