var searchData=
[
  ['port_134',['PORT',['../const_8h.html#a614217d263be1fb1a5f76e2ff7be19a2',1,'const.h']]],
  ['protocol_5fauto_5fchoice_135',['PROTOCOL_AUTO_CHOICE',['../server_8c.html#a5ff88a9edb41e87b8ef50ca0c3523b6d',1,'server.c']]]
];
