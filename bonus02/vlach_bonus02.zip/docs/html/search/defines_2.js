var searchData=
[
  ['client_5fso_5fnull_129',['CLIENT_SO_NULL',['../err__messages_8h.html#aa0dba4492ad530aa6c531809bc9b826c',1,'CLIENT_SO_NULL():&#160;err_messages.h'],['../server_8c.html#aa0dba4492ad530aa6c531809bc9b826c',1,'CLIENT_SO_NULL():&#160;server.c']]]
];
