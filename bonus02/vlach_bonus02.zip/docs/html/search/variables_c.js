var searchData=
[
  ['validation_5ffail_125',['VALIDATION_FAIL',['../namespaceclient.html#acaa6b5635e6f42fe19a7e132239ccb05',1,'client']]],
  ['validation_5ffail_5fstr_126',['VALIDATION_FAIL_STR',['../namespaceclient.html#abe8b211f98da2d5f51091e9da5b2b049',1,'client']]]
];
