var searchData=
[
  ['handle_5fclient_5fio_18',['handle_client_io',['../server_8c.html#abc4660afb4290ace1e3f344d5540e519',1,'server.c']]],
  ['handle_5fnew_5fconnection_19',['handle_new_connection',['../server_8c.html#af11902677d07ffcb19b534fc1bf99ac3',1,'server.c']]],
  ['handle_5fsession_5fauthentication_20',['handle_session_authentication',['../server_8c.html#aabe7094958007b8f6c9867901bd70ec4',1,'server.c']]],
  ['handle_5fsession_5fvalidation_21',['handle_session_validation',['../server_8c.html#aa9ae9dcf69022f67c70f6658e6258fec',1,'server.c']]],
  ['host_22',['HOST',['../namespaceclient.html#ad39c4666bbab8c2e37b88274a0eaf7ba',1,'client']]]
];
