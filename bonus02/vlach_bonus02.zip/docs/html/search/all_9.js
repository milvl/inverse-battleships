var searchData=
[
  ['main_25',['main',['../namespaceclient.html#a18d2f0bd3df369370bdb40b86fe2892b',1,'client.main()'],['../server_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;server.c']]],
  ['master_5fso_5fnull_26',['MASTER_SO_NULL',['../err__messages_8h.html#a341d5427680e78dfe2f9d3cbc8c895a6',1,'MASTER_SO_NULL():&#160;err_messages.h'],['../server_8c.html#a341d5427680e78dfe2f9d3cbc8c895a6',1,'MASTER_SO_NULL():&#160;server.c']]],
  ['max_5fclients_27',['MAX_CLIENTS',['../const_8h.html#a0a8f91f93d75a07f0ae45077db45b3eb',1,'const.h']]],
  ['max_5fpending_5fconnections_28',['MAX_PENDING_CONNECTIONS',['../server_8c.html#a5e22ab502256881f89a9aa2e2c94fc84',1,'server.c']]]
];
