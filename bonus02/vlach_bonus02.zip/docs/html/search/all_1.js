var searchData=
[
  ['add_5factive_5fsockets_1',['add_active_sockets',['../server_8c.html#ab06dbbfca702b294a4639ae8e6bd6691',1,'server.c']]],
  ['authentication_5ffail_2',['AUTHENTICATION_FAIL',['../namespaceclient.html#a50706883d78d3054072380e94a70f28e',1,'client']]]
];
