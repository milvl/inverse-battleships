var searchData=
[
  ['server_5fip_139',['SERVER_IP',['../const_8h.html#a28d06fc286f28044ed3380969700ff3f',1,'const.h']]],
  ['session_5fstate_5fauthorized_140',['SESSION_STATE_AUTHORIZED',['../session_8h.html#acaafe55ec737693e44ac786cd3fe23a9',1,'session.h']]],
  ['session_5fstate_5fconnected_141',['SESSION_STATE_CONNECTED',['../session_8h.html#a1272ee1217254f6492fedc768e3d01e6',1,'session.h']]],
  ['socket_5fnot_5fset_142',['SOCKET_NOT_SET',['../server_8c.html#ad971b4d2ddc252fdd99deb269ef21263',1,'server.c']]]
];
