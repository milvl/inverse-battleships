var searchData=
[
  ['size_122',['size',['../structsession__set.html#a36f670bfc6680dfb8851de339a879f29',1,'session_set']]],
  ['state_123',['state',['../structsession.html#a29e906021d1fdd3e7820053f4329d5ab',1,'session']]]
];
