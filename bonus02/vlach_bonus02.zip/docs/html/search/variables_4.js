var searchData=
[
  ['elem_5fsize_115',['elem_size',['../structsession__set.html#af5633c29a8c30bc22a567b6f11f347b8',1,'session_set']]]
];
