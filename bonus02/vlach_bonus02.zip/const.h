#ifndef __CONST_H
#define __CONST_H

#define SERVER_IP "127.0.0.1"
#define PORT 8080
#define MAX_CLIENTS 30
#define BUFFER_SIZE 1024

#endif