var searchData=
[
  ['calc_5fserver_5fport_30',['CALC_SERVER_PORT',['../client_8c.html#acf4479bc840f907106cc9ce40976e783',1,'client.c']]]
];
