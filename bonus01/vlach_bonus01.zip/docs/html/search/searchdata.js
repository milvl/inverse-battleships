var indexSectionsWithContent =
{
  0: "bcehimnprs",
  1: "c",
  2: "hms",
  3: "bceinprs"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Macros"
};

