var searchData=
[
  ['handle_5fcalc_5fserver_8',['handle_calc_server',['../client_8c.html#ab58f4fc6a9df17e774e134d225f7a788',1,'client.c']]],
  ['handle_5fecho_5fserver_9',['handle_echo_server',['../client_8c.html#a39a4ca563fc50f32e538e5c05ceb08fe',1,'client.c']]],
  ['handle_5freverse_5fserver_10',['handle_reverse_server',['../client_8c.html#a5e5937be2da4c8c07331874a7211b6bd',1,'client.c']]]
];
