var searchData=
[
  ['return_5ffail_15',['RETURN_FAIL',['../client_8c.html#a837fc3a8b3b8209d20399ad2a02c1ae7',1,'client.c']]],
  ['return_5fok_16',['RETURN_OK',['../client_8c.html#ab747ac432edef91062f2946bb521e49f',1,'client.c']]],
  ['reverse_5fserver_5fport_17',['REVERSE_SERVER_PORT',['../client_8c.html#a42ddba35602a261e5e6811389b256bcb',1,'client.c']]]
];
