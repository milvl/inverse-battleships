var searchData=
[
  ['send_5fand_5freceive_18',['send_and_receive',['../client_8c.html#a2ee5e3c22276a1e67941900eeb5b68f1',1,'client.c']]],
  ['server_5faddress_19',['SERVER_ADDRESS',['../client_8c.html#aa6cecb8c404241c624e83aee8a3979d2',1,'client.c']]],
  ['sock_5finvalid_20',['SOCK_INVALID',['../client_8c.html#a5ae6965a8252c65a4826c7eb51cd5f7b',1,'client.c']]]
];
