var searchData=
[
  ['break_5floop_0',['BREAK_LOOP',['../client_8c.html#aeb65a3a8f7335c07ca15bf40c96a049e',1,'client.c']]],
  ['bytes_5fserver_5freply_5fbuffer_1',['BYTES_SERVER_REPLY_BUFFER',['../client_8c.html#ae78b5e9f7016633c2bd2efaf87a2d1bf',1,'client.c']]],
  ['bytes_5fuser_5finput_5fbuffer_5fsize_2',['BYTES_USER_INPUT_BUFFER_SIZE',['../client_8c.html#a4c79a63d87d5ea1fc1f874f73a564157',1,'client.c']]]
];
