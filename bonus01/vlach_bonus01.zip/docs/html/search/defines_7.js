var searchData=
[
  ['server_5faddress_40',['SERVER_ADDRESS',['../client_8c.html#aa6cecb8c404241c624e83aee8a3979d2',1,'client.c']]],
  ['sock_5finvalid_41',['SOCK_INVALID',['../client_8c.html#a5ae6965a8252c65a4826c7eb51cd5f7b',1,'client.c']]]
];
