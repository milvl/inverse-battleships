var searchData=
[
  ['send_5fand_5freceive_26',['send_and_receive',['../client_8c.html#a2ee5e3c22276a1e67941900eeb5b68f1',1,'client.c']]]
];
