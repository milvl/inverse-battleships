var searchData=
[
  ['calc_5fserver_5fport_3',['CALC_SERVER_PORT',['../client_8c.html#acf4479bc840f907106cc9ce40976e783',1,'client.c']]],
  ['client_2ec_4',['client.c',['../client_8c.html',1,'']]]
];
